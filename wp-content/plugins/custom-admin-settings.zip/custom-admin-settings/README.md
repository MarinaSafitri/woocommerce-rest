# Custom Admin Settings

@TODO

## Description

@TODO

## Installation

Once you download a copy of the plugin, there are multiple ways to install it.

### Using The WordPress Dashboard

1. Navigate to the 'Add New' Plugin page
2. Select `custom-admin-settings.zip` from your computer
3. Click 'Upload'
4. Activate the plugin on the WordPress Plugin Dashboard

### Using FTP

1. Extract `custom-admin-settings.zip.zip` to your computer
2. Upload the `custom-admin-settings.zip` directory to your `wp-content/plugins`
   directory
3. Activate the plugin on the WordPress Plugins dashboard
