<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/* This is function file of the child theme, this is loaded BEFORE the parent themes function file is loaded , so you can override any function by declaring it here first. */

/*-----------------------------------------------------------------------------------*/
/* You can add custom functions below. */
/*-----------------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------------*/
/* Load style.css in the <head> */
/*-----------------------------------------------------------------------------------*/

add_action( 'wp_enqueue_scripts', 'tt_rm_responsive_css', 22 ); // we dont need responsive-rtl.css anymore as for RTL resp styles are merged in rtl.css
if ( ! function_exists( 'tt_rm_responsive_css' ) ) {
	function tt_rm_responsive_css() {
		wp_dequeue_style( 'temp-responsive' );
	} // End tt_rm_responsive_css()
}

if ( ! function_exists( 'woo_load_frontend_css' ) ) {
	function woo_load_frontend_css () {
		wp_register_style( 'theme-stylesheet', get_stylesheet_uri() );
		if ( is_rtl() ) {
			wp_register_style( 'woo-layout', get_stylesheet_directory_uri() . '/css/layout-rtl.css' );
		} else {
			wp_register_style( 'woo-layout', get_template_directory_uri() . '/css/layout.css' );
			}
		wp_enqueue_style( 'theme-stylesheet' );
		wp_enqueue_style( 'woo-layout' );
	} // End woo_load_frontend_css()
}

if ( ! function_exists( 'woo_load_woocommerce_css' ) ) {
	function woo_load_woocommerce_css() {
		if ( is_rtl() ) {
			wp_register_style( 'woocommerce', esc_url( get_stylesheet_directory_uri() . '/css/woocommerce-rtl.css' ) );
		} else {
			wp_register_style( 'woocommerce', esc_url( get_template_directory_uri() . '/css/woocommerce.css' ) );
		}
			wp_enqueue_style( 'woocommerce' );
	} // End woo_load_woocommerce_css()
}

if ( ! function_exists( 'tt_add_bxslider' ) ) {
	function tt_add_bxslider() {
		if ( is_rtl() ) {
			wp_register_script( 'tt-bxslider', get_stylesheet_directory_uri() . '/includes/js/bxslider-rtl.min.js', array( 'jquery' ),false,true );
		} else {
			wp_register_script( 'tt-bxslider', get_stylesheet_directory_uri() . '/includes/js/bxslider.min.js', array( 'jquery' ),false,true );
		}
		wp_enqueue_script( 'tt-bxslider','','','',true );

	} // End tt_add_bxslider()
}

// Add stylesheet for shortcodes to HEAD (added to HEAD in admin-setup.php)
function woo_shortcode_stylesheet() {
		echo "\n" . "<!-- Woo Shortcodes CSS -->\n";
		if ( is_rtl() ) {
		echo '<link href="'. get_stylesheet_directory_uri() . '/functions/css/shortcodes-rtl.css" rel="stylesheet" type="text/css" />'."\n";
		} else {
		echo '<link href="'. get_template_directory_uri() . '/functions/css/shortcodes.css" rel="stylesheet" type="text/css" />'."\n";
		}
} // End woo_shortcode_stylesheet()

function tt_remove_responsive_design () {
	wp_register_style( 'theme-stylesheet', get_stylesheet_uri() );
	if ( is_rtl() ) {
		wp_register_style( 'non-responsive', esc_url( get_stylesheet_directory_uri() . '/css/non-responsive-rtl.css' ) );
	} else {
		wp_register_style( 'non-responsive', esc_url( get_template_directory_uri() . '/css/non-responsive.css' ) );
	}
	// Load in CSS file for non-responsive layouts.
	wp_enqueue_style( 'theme-stylesheet' );
	wp_enqueue_style( 'non-responsive' );
	// Load non-responsive site width CSS.
	//add_action( 'wp_print_scripts', 'woo_load_site_width_css_nomedia', 10 );
} // End tt_remove_responsive_design()


/*-----------------------------------------------------------------------------------*/
/* Don't add any code below here. */
/*-----------------------------------------------------------------------------------*/
?>